<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Carbon\Carbon;
use App\Jobs\ProcessEndMonthLoansJob;

class LoanEndMonthController extends Controller
{
    private $currentPeriod;

    public function __construct()
    {
        ini_set('max_execution_time', 6000); // 10 minutes
        set_time_limit(6000);
        $this->middleware('auth');
        // Set the current period only once
        $this->currentPeriod = DB::table('sacco_period')
            ->where('period_active', 'Y')
            ->where('period_deleted', '<>', 'Y')
            ->first();
    }

    // Display the end-month loan processing page
    public function endMonthLoans(Request $request)
    {
        // Retrieve search input with default values
        $searchInstitution = $request->input('search_institution', '');
        $searchLoanType = $request->input('search_loan_type', '');
        $periodName = $this->currentPeriod->period_name;
$cutOffDate = $this->getCutOffDate($periodName);
        $minLoanAmountBillable = $this->getDefaultAccountValue('min_loan_amount_bill_able') ?? 1;

        try {
            // Build the query with joins and aggregate calculation
            $query = DB::table('sacco_company')
                ->join('sacco_department', 'sacco_department.department_company_id', '=', 'sacco_company.company_id')
                ->join('sacco_members', 'sacco_members.member_dept', '=', 'sacco_department.department_id')
                ->join('sacco_loans', 'sacco_loans.loan_member', '=', 'sacco_members.member_id')
                ->join('sacco_loan_types', 'sacco_loans.loan_loan_type', '=', 'sacco_loan_types.loan_type_id')
                ->select(
                    'sacco_company.company_name',
                    'sacco_loan_types.loan_type_name',
                    'sacco_company.company_id',
                    'sacco_loan_types.loan_type_id', // Include loan_type_id here
                    DB::raw('SUM(sacco_loans.loan_monthly_repayment_amount) AS lr_m_payment')
                )
                ->where([
                    ['sacco_members.member_deleted', '!=', 'Y'],
                    ['sacco_members.member_active', '=', 'Y'],
                    ['sacco_members.member_date_joined', '<=', $cutOffDate],
                    ['sacco_company.company_account', '>', 0],
                    ['sacco_loans.loan_amount', '>', 0],
                    ['sacco_loans.loan_stoped', '!=', 'Y'],
                    ['sacco_loans.loan_taken_period', '<=', $periodName],
                    ['sacco_loans.loan_start_deduction_period', '<=', $periodName]
                ])
                ->whereRaw('(sacco_loans.loan_amount - sacco_loans.loan_loan_paid) > ?', [$minLoanAmountBillable]);

            // Apply search filters if specified
            if (!empty($searchInstitution)) {
                $query->where('sacco_company.company_name', 'like', '%' . $searchInstitution . '%');
            }
            if (!empty($searchLoanType)) {
                $query->where('sacco_loan_types.loan_type_name', 'like', '%' . $searchLoanType . '%');
            }

            // Group, order, and get results
            $companies = $query->groupBy(
                'sacco_company.company_name',
                'sacco_loan_types.loan_type_name',
                'sacco_company.company_id',
                'sacco_loan_types.loan_type_id' // Group by loan_type_id to match selection
            )
                ->orderBy('sacco_company.company_name', 'asc')
                ->get();

            // Return the view with retrieved data
            return view('loans.end_month_processing', [
                'companies' => $companies,
                'currentPeriod' => $this->currentPeriod,
                'searchInstitution' => $searchInstitution,
                'searchLoanType' => $searchLoanType
            ]);
        } catch (\Exception $e) {
            // Log the error and redirect back with an error message
            Log::error('Error retrieving end month loan data: ' . $e->getMessage());
            return redirect()->back()->withErrors(['error' => 'Failed to retrieve loan data. Please try again later.']);
        }
    }

    //     public function endMonthLoans(Request $request)
    // {
    //     // Retrieve search input
    //     $searchInstitution = $request->input('search_institution');
    //     $searchLoanType = $request->input('search_loan_type');

    //     // Build the query
    //     $query = DB::table('sacco_company')
    //         ->join('sacco_department', 'sacco_department.department_company_id', '=', 'sacco_company.company_id')
    //         ->join('sacco_members', 'sacco_members.member_dept', '=', 'sacco_department.department_id')
    //         ->join('sacco_loans', 'sacco_loans.loan_member', '=', 'sacco_members.member_id')
    //         ->join('sacco_loan_types', 'sacco_loans.loan_loan_type', '=', 'sacco_loan_types.loan_type_id')
    //         ->select(
    //             'sacco_company.company_name',
    //             'sacco_loan_types.loan_type_name',
    //             'sacco_company.company_id',
    //             DB::raw('SUM(sacco_loans.loan_monthly_repayment_amount) AS lr_m_payment')
    //         )
    //         ->where('sacco_members.member_deleted', '!=', 'Y')
    //         ->where('sacco_members.member_active', 'Y')
    //         ->where('sacco_members.member_date_joined', '<=', $this->getCutOffDate())
    //         ->where('sacco_company.company_account', '>', 0)
    //         ->whereRaw('(sacco_loans.loan_amount - sacco_loans.loan_loan_paid) > ?', [$this->getDefaultAccountValue('min_loan_amount_bill_able') ?? 1])
    //         ->where('sacco_loans.loan_amount', '>', 0)
    //         ->where('sacco_loans.loan_stoped', '!=', 'Y')
    //         ->where('sacco_loans.loan_taken_period', '<=', $this->currentPeriod->period_name) // Existing condition
    //         ->where('sacco_loans.loan_start_deduction_period', '<=', $this->currentPeriod->period_name); // Added condition

    //     // Apply search filters
    //     if ($searchInstitution) {
    //         $query->where('sacco_company.company_name', 'like', '%' . $searchInstitution . '%');
    //     }
    //     if ($searchLoanType) {
    //         $query->where('sacco_loan_types.loan_type_name', 'like', '%' . $searchLoanType . '%');
    //     }

    //     // Get results
    //     $companies = $query->groupBy(
    //         'sacco_company.company_name',
    //         'sacco_loan_types.loan_type_name',
    //         'sacco_company.company_id'
    //     )
    //     ->orderBy('sacco_company.company_name', 'asc')
    //     ->get();

    //     // Return the view with search data
    //     return view('loans.end_month_processing', [
    //         'companies' => $companies,
    //         'currentPeriod' => $this->currentPeriod,
    //         'searchInstitution' => $searchInstitution,
    //         'searchLoanType' => $searchLoanType
    //     ]);
    // }

    // Process end-month loan payments
    // public function processEndMonthLoans(Request $request)
    // {
    //     $submittedCount = $request->input('submitted');
    //     $errors = [];

    //     DB::beginTransaction();

    //     try {
    //         for ($i = 0; $i < $submittedCount; $i++) {
    //             $companyId = $request->input("update{$i}");
    //             $loanDocNo = $request->input("loan_doc_no{$i}");
    //             $loanDatePaid = $request->input("loan_date_paid{$i}");
    //             $loanTypeId = $request->input("loan_type_e{$i}");

    //             if (is_numeric($companyId) && is_numeric($loanTypeId)) {
    //                 // Validate or set default for loan date paid
    //                 $loanDatePaid = $loanDatePaid ?? Carbon::now()->toDateString();

    //                 // Perform monthly repayment update for the specific loan type and company
    //                 $this->updateMonthlyRepayments($companyId, $loanTypeId, $loanDocNo, $loanDatePaid);
    //             }
    //         }

    //         DB::commit();
    //         return redirect()->route('proc.end.month.loans')->with('success', 'End-month loan processing completed successfully.');
    //     } catch (\Exception $e) {
    //         DB::rollBack();
    //         Log::error('End-month loan processing failed: ' . $e->getMessage());
    //         return redirect()->route('proc.end.month.loans')->with('error', 'End-month loan processing failed: ' . $e->getMessage());
    //     }
    // }

    // Retrieve the cut-off date from defaults, using today's date if it doesn't exist
    private function getCutOffDate($periodName = null)
{
    /*
    |--------------------------------------------------------------------------
    | Loan end-month cutoff
    |--------------------------------------------------------------------------
    | sacco_defaults.cut_off_date must be a DAY NUMBER only.
    |
    | Valid:
    |   28  => active period 202606 becomes 2026-06-28
    |
    | Invalid / missing / full date:
    |   NULL       => use 28
    |   2025-10-28 => ignore and use 28
    |   abc        => use 28
    */

    $periodName = $periodName ?: optional($this->currentPeriod)->period_name;

    if (empty($periodName) || !preg_match('/^\d{6}$/', (string) $periodName)) {
        throw new \RuntimeException('Invalid SACCO period for loan cutoff date.');
    }

    $rawCutoffDay = DB::table('sacco_defaults')
        ->where('default_name', 'cut_off_date')
        ->value('default_value');

    $cutoffDay = 28;

    if ($rawCutoffDay === null || trim((string) $rawCutoffDay) === '') {
        DB::table('sacco_defaults')->insert([
            'default_name'      => 'cut_off_date',
            'default_value'     => 28,
            'default_transdate' => now(),
            'default_userid'    => auth()->id() ?? 1,
            'default_ip'        => request()->ip(),
        ]);

        Log::warning("Default 'cut_off_date' missing — inserted day 28.");
    } else {
        $rawCutoffDay = trim((string) $rawCutoffDay);

        // Accept day number only. Full dates like 2025-10-28 are ignored.
        if (ctype_digit($rawCutoffDay)) {
            $cutoffDay = (int) $rawCutoffDay;
        }
    }

    // February-safe: maximum allowed cutoff day is 28.
    $cutoffDay = max(1, min($cutoffDay, 28));

    $periodMonth = Carbon::createFromFormat('Ym', (string) $periodName)->startOfMonth();

    return $periodMonth
        ->copy()
        ->day($cutoffDay)
        ->toDateString();
}

    // Retrieve default account values based on the account name
    private function getDefaultAccountValue($accountName)
    {
        return DB::table('sacco_defaults')
            ->where('default_name', $accountName)
            ->value('default_value');
    }

    // Update monthly loan repayments for specified loans
    private function updateMonthlyRepayments($companyId, $loanTypeId, $loanDocNo, $loanDatePaid)
    {
        $loans = DB::table('sacco_loans')
            ->join('sacco_members', 'sacco_members.member_id', '=', 'sacco_loans.loan_member')
            ->where('sacco_members.member_active', 'Y')
            ->where('sacco_loans.loan_loan_type', $loanTypeId)
            ->where('sacco_members.member_dept', $companyId)
            ->whereRaw('(loan_amount - loan_loan_paid) > 0')
            ->select('loan_id', 'loan_monthly_repayment_amount')
            ->get();

        foreach ($loans as $loan) {
            // Update loan balance
            DB::table('sacco_loans')
                ->where('loan_id', $loan->loan_id)
                ->increment('loan_loan_paid', $loan->loan_monthly_repayment_amount);

            // Log repayment in sacco_loan_payments
            DB::table('sacco_loan_payments')->insert([
                'loan_payments_amount' => $loan->loan_monthly_repayment_amount,
                'loan_payments_docno' => $loanDocNo,
                'loan_payments_paid_on' => $loanDatePaid,
                'loan_payments_loan_id' => $loan->loan_id,
                'loan_payments_by' => auth()->id(),
                'loan_payments_ip' => request()->ip(),
                'loan_payments_period' => $this->currentPeriod->period_name
            ]);
        }
    }


    // public function processEndMonthLoans(Request $request)
    // {
    //     $submittedCount = $request->input('submitted');
    //     $errors = [];
    //     $validRows = [];
    //     $period = $this->currentPeriod->period_name;

    //     // **Step 1: Validation Loop**
    //     for ($i = 0; $i < $submittedCount; $i++) {
    //         $companyId = $request->input("update{$i}");

    //         if (!$companyId) {
    //             continue; // Skip if not selected
    //         }

    //         $loanTypeId = $request->input("loan_type_e{$i}");
    //         $loanDocNo = $request->input("loan_doc_no{$i}");
    //         $loanDatePaid = $request->input("loan_date_paid{$i}");

    //         // Check if all required fields are filled
    //         if (empty($loanDocNo) || empty($loanDatePaid)) {
    //             $errors[] = "Row " . ($i + 1) . ": Missing document number or payment date for company ID $companyId and loan type $loanTypeId.";
    //             continue;
    //         }

    //         // Check if loanDatePaid is a valid date
    //         if (!$this->isValidDate($loanDatePaid)) {
    //             $errors[] = "Row " . ($i + 1) . ": Invalid payment date format for company ID $companyId and loan type $loanTypeId.";
    //             continue;
    //         }

    //         // Check if end-month processing has already been done for this entry
    //         if ($this->checkEndMonthProcessing($companyId, $loanTypeId, $period)) {
    //             $errors[] = "Row " . ($i + 1) . ": End-month processing for company ID $companyId, loan type $loanTypeId, and period $period has already been done.";
    //             continue;
    //         }

    //         // If all checks pass, add to validRows for processing
    //         $validRows[] = [
    //             'companyId' => $companyId,
    //             'loanTypeId' => $loanTypeId,
    //             'loanDocNo' => $loanDocNo,
    //             'loanDatePaid' => $loanDatePaid,
    //             'period' => $period
    //         ];
    //     }

    //     // If there are validation errors, redirect back without processing
    //     if (!empty($errors)) {
    //         return redirect()->route('proc.end.month.loans')->withErrors($errors);
    //     }

    //     // **Step 2: Processing Loop** (only if validation passed for all rows)
    //     DB::beginTransaction();

    //     try {
    //         foreach ($validRows as $row) {
    //             $this->defaultProcEndMonthLoanUpdate(
    //                 $row['companyId'],
    //                 $row['loanTypeId'],
    //                 $row['loanDocNo'],
    //                 $row['loanDatePaid'],
    //                 $row['period']
    //             );
    //         }

    //         DB::commit();
    //         return redirect()->route('proc.end.month.loans')->with('success', 'End-month loan processing completed successfully.');
    //     } catch (\Exception $e) {
    //         // Rollback if an error occurs
    //         DB::rollBack();
    //         Log::error('End-month loan processing failed: ' . $e->getMessage());
    //         return redirect()->route('proc.end.month.loans')->with('error', 'End-month loan processing failed: ' . $e->getMessage());
    //     }
    // }
    public function processEndMonthLoans(Request $request)
    {
        $submittedCount = $request->input('submitted');
        $errors = [];
        $validRows = [];
        $period = $this->currentPeriod->period_name;

        // **Step 1: Validation Loop**
        for ($i = 0; $i < $submittedCount; $i++) {
            $companyId = $request->input("update{$i}");

            if (!$companyId) {
                continue; // Skip if not selected
            }

            $loanTypeId = $request->input("loan_type_e{$i}");
            $loanDocNo = $request->input("loan_doc_no{$i}");
            $loanDatePaid = $request->input("loan_date_paid{$i}");

            // Check if all required fields are filled
            if (empty($loanTypeId) || empty($loanDocNo) || empty($loanDatePaid)) {
                $errors[] = "Row " . ($i + 1) . ": Missing loan type, document number, or payment date for company ID $companyId.";
                continue;
            }

            // Check if loanDatePaid is a valid date
            if (!$this->isValidDate($loanDatePaid)) {
                $errors[] = "Row " . ($i + 1) . ": Invalid payment date format for company ID $companyId and loan type $loanTypeId.";
                continue;
            }

            // Check if end-month processing has already been done for this entry
            if ($this->checkEndMonthProcessing($companyId, $loanTypeId, $period)) {
                $errors[] = "Row " . ($i + 1) . ": End-month processing for company ID $companyId, loan type $loanTypeId, and period $period has already been done.";
                continue;
            }

            // If all checks pass, add to validRows for processing
            $validRows[] = [
                'companyId' => $companyId,
                'loanTypeId' => $loanTypeId,
                'loanDocNo' => $loanDocNo,
                'loanDatePaid' => $loanDatePaid,
                'period' => $period
            ];
        }

        // If there are validation errors, redirect back without processing
     

        if (!empty($errors)) {
        return redirect()->route('proc.end.month.loans')->withErrors($errors);
    }

    Log::info('📦 Dispatching ProcessEndMonthLoansJob with rows: ' . json_encode($validRows));

    dispatch(new ProcessEndMonthLoansJob($validRows, $period));

    return redirect()
        ->route('proc.end.month.loans')
        ->with('success', 'End-month loan processing has been queued and will run in the background.');
       
    }
    /**
     * Helper function to validate date format.
     *
     * @param string $date
     * @return bool
     */
    private function isValidDate($date)
    {
        try {
            Carbon::parse($date);
            return true;
        } catch (\Exception $e) {
            return false;
        }
    }

    public function checkEndMonthProcessing($companyId, $loanTypeId, $period)
    {
        $minLoanAmountBillable = $this->getDefaultAccountValue('min_loan_amount_bill_able') ?? 1;

        // Query to check if end-month processing has been completed for this loan type, period, and company
        $existingPayments = DB::table('sacco_loan_payments')
            ->join('sacco_loans', 'sacco_loan_payments.loan_payments_loan_id', '=', 'sacco_loans.loan_id')
            ->join('sacco_members', 'sacco_loans.loan_member', '=', 'sacco_members.member_id')
            ->join('sacco_department', 'sacco_members.member_dept', '=', 'sacco_department.department_id')
            ->join('sacco_company', 'sacco_department.department_company_id', '=', 'sacco_company.company_id')
            ->join('sacco_loan_types', 'sacco_loans.loan_loan_type', '=', 'sacco_loan_types.loan_type_id')
            ->where('sacco_company.company_id', $companyId)
            ->where('sacco_loan_payments.loan_end_month_proc', 'Y')
            ->where('sacco_loan_payments.loan_payments_period', $period)
            ->where('sacco_loan_types.loan_type_id', $loanTypeId)
            ->exists();

        return $existingPayments; // returns true if processing has been done, false otherwise
    }
   public function defaultProcEndMonthLoanUpdate($companyId, $loanTypeId, $loanDocNo, $loanDatePaid)
{
    $period = $this->currentPeriod->period_name;
    $minLoanAmountBillable = $this->getDefaultAccountValue('min_loan_amount_bill_able') ?? 1;

    if (is_null($minLoanAmountBillable)) {
        DB::table('sacco_defaults')->insert([
            'default_name'      => 'min_loan_amount_bill_able',
            'default_value'     => 1,
            'default_transdate' => now(),
            'default_userid'    => auth()->id() ?? 1,
            'default_ip'        => request()->ip(),
        ]);
        Log::warning("Default 'min_loan_amount_bill_able' missing — inserted with value 1.");
        $minLoanAmountBillable = 1;
    }

    $cutOffDate = $this->getCutOffDate($period);

    // Step 1: Fetch loan type info
    $loanType = DB::table('sacco_loan_types')
        ->where('loan_type_id', $loanTypeId)
        ->select('loan_type_interest_type', 'loan_type_interest', 'loan_type_id')
        ->first();

    if (!$loanType) {
        Log::error("Loan type not found for ID {$loanTypeId}");
        return;
    }

    $loanInterestType = strtoupper(trim($loanType->loan_type_interest_type ?? ''));
    $loanInterestRate = (float) ($loanType->loan_type_interest ?? 0);

    // Step 2: Get global calc method
    $loanCalcMethod = DB::table('sacco_defaults')
        ->where('default_name', 'loan_calc_method')
        ->value('default_value');
    $loanCalcMethod = strtolower(trim($loanCalcMethod ?? ''));

    // Step 3: Chunk processing
    DB::table('sacco_loans')
        ->join('sacco_members', 'sacco_loans.loan_member', '=', 'sacco_members.member_id')
        ->join('sacco_department', 'sacco_members.member_dept', '=', 'sacco_department.department_id')
        ->join('sacco_company', 'sacco_department.department_company_id', '=', 'sacco_company.company_id')
        ->join('sacco_loan_types', 'sacco_loans.loan_loan_type', '=', 'sacco_loan_types.loan_type_id')
        ->where('sacco_department.department_company_id', $companyId)
        ->where('sacco_loans.loan_loan_type', $loanTypeId)
        ->where('sacco_members.member_active', 'Y')
        ->where('sacco_members.member_deleted', '!=', 'Y')
        ->where('sacco_members.member_date_joined', '<=', $cutOffDate)
        ->where('sacco_company.company_account', '>', 0)
        ->whereRaw('(COALESCE(sacco_loans.loan_amount, 0) - COALESCE(sacco_loans.loan_loan_paid, 0)) > ?', [$minLoanAmountBillable])
        ->where('sacco_loans.loan_amount', '>', 0)
        ->where('sacco_loans.loan_stoped', '!=', 'Y')
        ->where('sacco_loans.loan_taken_period', '<=', $period)
        ->where('sacco_loans.loan_start_deduction_period', '<=', $period)
        ->select(
            'sacco_loans.loan_id',
            'sacco_loans.loan_monthly_repayment_amount',
            'sacco_loans.loan_monthly_repayment_principal',
            'sacco_loans.loan_loan_paid',
            'sacco_loans.loan_amount',
            'sacco_loans.loan_amount_guaranteed',
            'sacco_members.member_id',
            'sacco_loan_types.loan_type_int_account',
            'sacco_loan_types.loan_type_acount',
            'sacco_company.company_account',
            'sacco_loan_types.loan_type_id'
        )
        ->orderBy('sacco_loans.loan_id')
        ->chunk(200, function ($loans) use ($companyId, $loanTypeId, $loanDocNo, $loanDatePaid, $period, $loanInterestType, $loanInterestRate, $loanCalcMethod) {

            $start = microtime(true);

            foreach ($loans as $loan) {
                try {
                    $actualCashPaid = round((float) ($loan->loan_monthly_repayment_amount ?? 0), 2);
$scheduledPrincipal = round((float) ($loan->loan_monthly_repayment_principal ?? 0), 2);

$interest = 0;

/*
|--------------------------------------------------------------------------
| Compute interest first.
|--------------------------------------------------------------------------
*/
if ($loanInterestType === "FIXED INTEREST") {
    if ($loanInterestRate > 0) {
        $interest = $actualCashPaid - ($actualCashPaid * 100 / ($loanInterestRate + 100));
    } else {
        $interest = 0;
    }
} else {
    $interest = (
        ((float) ($loan->loan_amount ?? 0) - (float) ($loan->loan_loan_paid ?? 0))
        * (float) $loanInterestRate / 12 / 100
    );
}

$interest = round((float) $interest, 2);

/*
|--------------------------------------------------------------------------
| Zero-payment override.
| If no cash was paid, interest must be capitalised into the loan.
|--------------------------------------------------------------------------
*/
if ($actualCashPaid <= 0 && $interest > 0) {
    $principalPayment = 0;
    $principalPaid = round(0 - $interest, 2);
} elseif ($loanCalcMethod === 'principle' && $loanInterestType !== "FIXED INTEREST") {
    /*
    |--------------------------------------------------------------------------
    | Fixed-principal mode:
    | principal is fixed, interest changes, total paid changes.
    |--------------------------------------------------------------------------
    */
    $principalPaid = $scheduledPrincipal;
    $principalPayment = round($scheduledPrincipal + $interest, 2);
} else {
    /*
    |--------------------------------------------------------------------------
    | Normal instalment mode:
    | actual total paid is split between interest and principal.
    |--------------------------------------------------------------------------
    */
    $principalPayment = $actualCashPaid;
    $principalPaid = round($actualCashPaid - $interest, 2);
}
                    $loanDescription = "Payroll {$period} - Member ID: {$loan->member_id}";

                    // Skip duplicates
                    $exists = DB::table('sacco_loan_payments')
                        ->where('loan_payments_docno', $loanDocNo)
                        ->where('loan_payments_loan_id', $loan->loan_id)
                        ->where('loan_payments_period', $period)
                        ->where('loan_payments_description', $loanDescription)
                        ->exists();

                    if ($exists) {
                        Log::info("⏩ Skipped duplicate payment for Loan ID {$loan->loan_id}, Doc {$loanDocNo}, Period {$period}");
                        continue;
                    }

                    // Insert payment
                    DB::table('sacco_loan_payments')->insert([
                        'loan_payments_amount'      => $principalPaid,
                        'loan_payments_interest'    => $interest,
                        'loan_payments_docno'       => $loanDocNo,
                        'loan_payments_paid_on'     => $loanDatePaid,
                        'loan_payments_loan_id'     => $loan->loan_id,
                        'loan_payments_period'      => $period,
                        'loan_payments_by'          => auth()->id(),
                        'loan_payments_ip'          => request()->ip(),
                        'loan_end_month_proc'       => 'Y',
                        'loan_payments_description' => $loanDescription,
                        'loan_payments_paid_in_by'  => "End Month Proc"
                    ]);

                    // Update balances
                    DB::table('sacco_loans')->where('loan_id', $loan->loan_id)->increment('loan_loan_paid', $principalPaid);
                    DB::table('sacco_members')->where('member_id', $loan->member_id)->decrement('member_total_loan', $principalPaid);

                    // Reducing balance recalculation
                    if ($loanCalcMethod === 'principle' && $loanInterestType !== "FIXED INTEREST") {
                        $this->recalculateReducingBalanceLoan($loan->loan_id, $loanInterestRate);
                    }

                    // Guarantor shares
                   if (
    $principalPaid > 0 &&
    is_numeric($loan->loan_amount_guaranteed) &&
    $loan->loan_amount_guaranteed > 0.1
) {
    $this->updateGuarantorShares($loan->loan_id, $principalPaid);
}

                    // Accounting records
                    $this->recordAccountingTransactions(
                        $loan, $companyId, $principalPaid, $interest, $loanDocNo, $period, $loanDatePaid
                    );
                } catch (\Exception $e) {
                    Log::error("Error processing loan ID {$loan->loan_id}: " . $e->getMessage());
                }
            }

            $time = round(microtime(true) - $start, 2);
            Log::info("✅ Processed chunk of " . count($loans) . " loans for Company {$companyId}, Loan Type {$loanTypeId} in {$time}s.");
        });

    Log::info("🏁 Completed end-month loan update for Company {$companyId}, Loan Type {$loanTypeId}");
}

    // public function defaultProcEndMonthLoanUpdate($companyId, $loanTypeId, $loanDocNo, $loanDatePaid)
    // {
    //     $period = $this->currentPeriod->period_name;
    //     $minLoanAmountBillable = $this->getDefaultAccountValue('min_loan_amount_bill_able') ?? 1;


    //     if (is_null($minLoanAmountBillable)) {
    //         DB::table('sacco_defaults')->insert([
    //             'default_name'      => 'min_loan_amount_bill_able',
    //             'default_value'     => 1,
    //             'default_transdate' => now(),
    //             'default_userid'    => auth()->id() ?? 1,
    //             'default_ip'        => request()->ip(),
    //         ]);

    //         Log::warning("Default 'min_loan_amount_bill_able' missing — inserted with value 1.");
    //         $minLoanAmountBillable = 1; // fallback immediately
    //     }

    //     $cutOffDate = $this->getCutOffDate($period);

    //     // Step 1: Fetch loan type once (instead of querying multiple times)
    //     $loanType = DB::table('sacco_loan_types')
    //         ->where('loan_type_id', $loanTypeId)
    //         ->select('loan_type_interest_type', 'loan_type_interest', 'loan_type_id')
    //         ->first();

    //     if (!$loanType) {
    //         Log::error("Loan type not found for ID {$loanTypeId}");
    //         return;
    //     }

    //     $loanInterestType = strtoupper(trim($loanType->loan_type_interest_type ?? ''));
    //     $loanInterestRate = (float) ($loanType->loan_type_interest ?? 0);

    //     // Step 2: Fetch global loan calculation method
    //     $loanCalcMethod = DB::table('sacco_defaults')
    //         ->where('default_name', 'loan_calc_method')
    //         ->value('default_value');

    //     if (is_null($loanCalcMethod)) {
    //         DB::table('sacco_defaults')->insert([
    //             'default_name'      => 'loan_calc_method',
    //             'default_value'     => null,
    //             'default_transdate' => now(),
    //             'default_userid'    => auth()->id() ?? 1,
    //             'default_ip'        => request()->ip(),
    //         ]);

    //         Log::warning('loan_calc_method missing — inserted null record in sacco_defaults.');
    //     }

    //     $loanCalcMethod = strtolower(trim($loanCalcMethod ?? ''));

    //     // Step 3: Get eligible loans
    //     $loans = DB::table('sacco_loans')
    //         ->join('sacco_members', 'sacco_loans.loan_member', '=', 'sacco_members.member_id')
    //         ->join('sacco_department', 'sacco_members.member_dept', '=', 'sacco_department.department_id')
    //         ->join('sacco_company', 'sacco_department.department_company_id', '=', 'sacco_company.company_id')
    //         ->join('sacco_loan_types', 'sacco_loans.loan_loan_type', '=', 'sacco_loan_types.loan_type_id')
    //         ->where('sacco_department.department_company_id', $companyId)
    //         ->where('sacco_loans.loan_loan_type', $loanTypeId)
    //         ->where('sacco_members.member_active', 'Y')
    //         ->where('sacco_members.member_deleted', '!=', 'Y')
    //         ->where('sacco_members.member_date_joined', '<=', $cutOffDate)
    //         ->where('sacco_company.company_account', '>', 0)
    //         // ->whereRaw('(sacco_loans.loan_amount - sacco_loans.loan_loan_paid) > ?', [$minLoanAmountBillable])
    //         ->whereRaw('(COALESCE(sacco_loans.loan_amount, 0) - COALESCE(sacco_loans.loan_loan_paid, 0)) > ?', [$minLoanAmountBillable])
    //         ->where('sacco_loans.loan_amount', '>', 0)
    //         ->where('sacco_loans.loan_stoped', '!=', 'Y')
    //         ->where('sacco_loans.loan_taken_period', '<=', $period)
    //         ->where('sacco_loans.loan_start_deduction_period', '<=', $period)
    //         ->select(
    //             'sacco_loans.loan_id',
    //             'sacco_loans.loan_monthly_repayment_amount',
    //             'sacco_loans.loan_monthly_repayment_principal',
    //             'sacco_loans.loan_loan_paid',
    //             'sacco_loans.loan_amount',
    //             'sacco_loans.loan_amount_guaranteed',
    //             'sacco_members.member_id',
    //             'sacco_loan_types.loan_type_int_account',
    //             'sacco_loan_types.loan_type_acount',
    //             'sacco_company.company_account',
    //             'sacco_loan_types.loan_type_id'
    //         )
    //         ->get();

    //     if ($loans->isEmpty()) {
    //         Log::info("No eligible loans for Company ID {$companyId}, Loan Type ID {$loanTypeId}.");
    //         return;
    //     }

    //     // Step 4: Process each loan
    //     foreach ($loans as $loan) {
    //         try {
    //             $principalPayment = (float) $loan->loan_monthly_repayment_amount;
    //             $interest = 0;



    //             // Compute interest
    //             if ($loanInterestType === "FIXED INTEREST") {
    //                 $interest = $principalPayment - ($principalPayment * 100 / ($loanInterestRate + 100));
    //             } else {
    //                 $interest = ($loan->loan_amount - $loan->loan_loan_paid) * $loanInterestRate / 12 / 100;
    //             }

    //             if ($loanCalcMethod === 'principle' && $loanInterestType !== "FIXED INTEREST") {
    //                 $principalPayment = $interest + $loan->loan_monthly_repayment_principal;
    //             }

    //             $principalPaid = $principalPayment - $interest;


    //             $loanDescription = "Payroll {$period} - Member ID: {$loan->member_id}";

    //             // ✅ Step 5: Skip duplicate sacco_loan_payments
    //         $exists = DB::table('sacco_loan_payments')
    //             ->where('loan_payments_docno', $loanDocNo)
    //             ->where('loan_payments_loan_id', $loan->loan_id)
    //             ->where('loan_payments_period', $period)
    //              ->where('loan_payments_description', $loanDescription)
    //             ->exists();

    //         if ($exists) {
    //             Log::info("⏩ Skipped duplicate payment for Loan ID {$loan->loan_id}, Doc {$loanDocNo}, Period {$period}");
    //             continue;
    //         }


    //             // Step 2: Insert into payments
    //             DB::table('sacco_loan_payments')->insert([
    //                 'loan_payments_amount'       => $principalPaid,
    //                 'loan_payments_interest'     => $interest,
    //                 'loan_payments_docno'        => $loanDocNo,
    //                 'loan_payments_paid_on'      => $loanDatePaid,
    //                 'loan_payments_loan_id'      => $loan->loan_id,
    //                 'loan_payments_period'       => $period,
    //                 'loan_payments_by'           => auth()->id(),
    //                 'loan_payments_ip'           => request()->ip(),
    //                 'loan_end_month_proc'        => 'Y',
    //                 'loan_payments_description'  => $loanDescription,
    //                 'loan_payments_paid_in_by'   => "End Month Proc"
    //             ]);

    //             // Step 3: Update balances
    //             DB::table('sacco_loans')
    //                 ->where('loan_id', $loan->loan_id)
    //                 ->increment('loan_loan_paid', $principalPaid);

    //             DB::table('sacco_members')
    //                 ->where('member_id', $loan->member_id)
    //                 ->decrement('member_total_loan', $principalPaid);

    //             // Step 3b: Recalculate for principle method
    //             if ($loanCalcMethod === 'principle' && $loanInterestType !== "FIXED INTEREST") {
    //                 $this->recalculateReducingBalanceLoan($loan->loan_id, $loanInterestRate);
    //             }

    //             // Step 4: Update guarantors
    //             if (is_numeric($loan->loan_amount_guaranteed) && $loan->loan_amount_guaranteed > 0.1) {
    //                 $this->updateGuarantorShares($loan->loan_id, $principalPaid);
    //             }

    //             // Step 5: Record accounting
    //             $this->recordAccountingTransactions(
    //                 $loan,
    //                 $companyId,
    //                 $principalPaid,
    //                 $interest,
    //                 $loanDocNo,
    //                 $period,
    //                 $loanDatePaid
    //             );
    //         } catch (\Exception $e) {
    //             Log::error("Error processing loan ID {$loan->loan_id}: " . $e->getMessage());
    //             continue; // continue to next loan without breaking the batch
    //         }
    //     }

    //     Log::info("✅ End-month loan update completed for Company {$companyId}, Loan Type {$loanTypeId}");
    // }

   
    private function updateGuarantorShares($loanId, $principalPaid)
    {
        // Retrieve the loan's total amount guaranteed and loan member
        $loan = DB::table('sacco_loans')
            ->where('loan_id', $loanId)
            ->select('loan_amount_guaranteed', 'loan_member')
            ->first();

        if (!$loan) {
            throw new \Exception("Loan not found for ID {$loanId}");
        }

        $totalLoanGuaranteed = $loan->loan_amount_guaranteed;

        // Check if the loan amount guaranteed is valid to avoid division by zero
        if ($totalLoanGuaranteed <= 0) {
            throw new \Exception("Invalid loan amount guaranteed for loan ID {$loanId}");
        }

        // Retrieve all guarantors for the specified loan
        $guarantors = DB::table('sacco_loan_guarantors')
            ->join('sacco_members', 'sacco_loan_guarantors.loan_guar_guarantor_id', '=', 'sacco_members.member_id')
            ->where('sacco_loan_guarantors.loan_guar_loan_id', $loanId)
            ->where('sacco_loan_guarantors.loan_guar_deleted', '!=', 'Y')
            ->select(
                'sacco_loan_guarantors.loan_guar_id',
                'sacco_loan_guarantors.loan_guar_guarantor_id',
                'sacco_loan_guarantors.loan_guar_amount_guaranteed',
                'sacco_loan_guarantors.loan_guar_amount_freed',
                'sacco_members.member_tied_shares',
                'sacco_members.member_tied_shares_self'
            )
            ->get();

        foreach ($guarantors as $guarantor) {
            // Calculate the amount to free based on the prorated share of the guarantee
            $guaranteedShare = $guarantor->loan_guar_amount_guaranteed;
            $amountToFree = ($guaranteedShare / $totalLoanGuaranteed) * $principalPaid;

            // Check if the guarantor is self-guaranteeing or guaranteeing someone else
            if ($guarantor->loan_guar_guarantor_id == $loan->loan_member) {
                // Self-guaranteeing, decrement member_tied_shares_self only
                DB::table('sacco_members')
                    ->where('member_id', $guarantor->loan_guar_guarantor_id)
                    ->decrement('member_tied_shares_self', $amountToFree);
            } else {
                // Guaranteeing someone else, decrement member_tied_shares only
                DB::table('sacco_members')
                    ->where('member_id', $guarantor->loan_guar_guarantor_id)
                    ->decrement('member_tied_shares', $amountToFree);
            }

            // Update loan_guar_amount_freed in sacco_loan_guarantors table
            DB::table('sacco_loan_guarantors')
                ->where('loan_guar_id', $guarantor->loan_guar_id)
                ->increment('loan_guar_amount_freed', $amountToFree);

            Log::info("Freed amount for guarantor ID {$guarantor->loan_guar_guarantor_id}: $amountToFree");
        }
    }
    private function recordAccountingTransactions($loan, $companyId, $principalPaid, $interest, $loanDocNo, $period, $loanDatePaid)
    {

        // Define the loan description based on the period and member ID
        $loanDescription = "Payroll $period - Member ID: " . $loan->member_id;

        // Fetch the specific accounts for principal, interest, and the company
        $principalAccount = $loan->loan_type_acount; // Loan principal account
        $interestAccount = $loan->loan_type_int_account; // Loan interest account
        $companyAccount = $loan->company_account; // Company account
        $loan_type_id = $loan->loan_type_id;

        // Ensure all accounts are valid
        if (!$principalAccount || !$interestAccount || !$companyAccount) {
            throw new \Exception("Account information is incomplete for loan processing.");
        }

        // Step 1: Credit the principal account for the loan with the principal paid amount
        $this->updateSaccoAccountsTrans([
            'sub_account' => $principalAccount,
            'debit' => 0,
            'credit' => $principalPaid,
            'doc_no' => $loanDocNo,
            'description' => $loanDescription,
            'date' => $loanDatePaid,
            'period' => $period,
            'member_id' => $loan->member_id, // Adding member_id for updateSaccoAccountsTrans
            'loan_type_id' => $loan->loan_type_id, // Adding loan_type_id for updateSaccoAccountsTrans
            'company_id' => $companyId, // Adding company_id for updateSaccoAccountsTrans
        ]);

        // Step 2: Credit the interest account for the loan with the calculated interest
        $this->updateSaccoAccountsTrans([
            'sub_account' => $interestAccount,
            'debit' => 0,
            'credit' => $interest,
            'doc_no' => $loanDocNo,
            'description' => $loanDescription,
            'date' => $loanDatePaid,
            'period' => $period,
            'member_id' => $loan->member_id,
            'loan_type_id' => $loan->loan_type_id,
            'company_id' => $companyId,
        ]);

        // Step 3: Debit the company's account for the total of principal + interest
        $this->updateSaccoAccountsTrans([
            'sub_account' => $companyAccount,
            'debit' => $principalPaid + $interest,
            'credit' => 0,
            'doc_no' => $loanDocNo,
            'description' => $loanDescription,
            'date' => $loanDatePaid,
            'period' => $period,
            'member_id' => $loan->member_id,
            'loan_type_id' => $loan->loan_type_id,
            'company_id' => $companyId,
        ]);
    }
    // private function recordAccountingTransactions($loan, $companyId, $principalPaid, $interest, $loanDocNo, $period, $loanDatePaid)
    // {
    //     // Define the loan description based on the period and member ID
    //     $loanDescription = "Payroll $period - Member ID: " . $loan->member_id;

    //     // Fetch the specific accounts for principal, interest, and the company
    //     $principalAccount = $loan->loan_type_acount; // Loan principal account
    //     $interestAccount = $loan->loan_type_int_account; // Loan interest account
    //     $companyAccount = $loan->company_account; // Company account

    //     // Ensure all accounts are valid
    //     if (!$principalAccount || !$interestAccount || !$companyAccount) {
    //         throw new \Exception("Account information is incomplete for loan processing.");
    //     }

    //     // Step 1: Credit the principal account for the loan with the principal paid amount
    //     $this->updateSaccoAccountsTrans([
    //         'sub_account' => $principalAccount,
    //         'debit' => 0,
    //         'credit' => $principalPaid,
    //         'doc_no' => $loanDocNo,
    //         'description' => $loanDescription,
    //         'date' => $loanDatePaid,
    //         'period' => $period,
    //     ]);

    //     // Step 2: Credit the interest account for the loan with the calculated interest
    //     $this->updateSaccoAccountsTrans([
    //         'sub_account' => $interestAccount,
    //         'debit' => 0,
    //         'credit' => $interest,
    //         'doc_no' => $loanDocNo,
    //         'description' => $loanDescription,
    //         'date' => $loanDatePaid,
    //         'period' => $period,
    //     ]);

    //     // Step 3: Debit the company's account for the total of principal + interest
    //     $this->updateSaccoAccountsTrans([
    //         'sub_account' => $companyAccount,
    //         'debit' => $principalPaid + $interest,
    //         'credit' => 0,
    //         'doc_no' => $loanDocNo,
    //         'description' => $loanDescription,
    //         'date' => $loanDatePaid,
    //         'period' => $period,
    //     ]);
    // }

    private function updateSaccoAccountsTrans(array $data)
    {

        try {
            $userId = auth()->id(); // Get the logged-in user ID
            $userIp = request()->ip(); // Get the IP address

            // Fetch additional details for the description
            $member = DB::table('sacco_members')
                ->select('member_name')
                ->where('member_id', $data['member_id'])
                ->first();

            if (!$member) {
                dd("Error: Member not found for ID {$data['member_id']}");
            }

            $loanType = DB::table('sacco_loan_types')
                ->select('loan_type_name')
                ->where('loan_type_id', $data['loan_type_id'])
                ->first();

            if (!$loanType) {
                dd("Error: Loan type not found for ID {$data['loan_type_id']}");
            }

            $company = DB::table('sacco_company')
                ->select('company_name')
                ->where('company_id', $data['company_id'])
                ->first();

            if (!$company) {
                dd("Error: Company not found for ID {$data['company_id']}");
            }

            // Construct enhanced description
            $description = "Payroll {$data['period']} - Member ID: {$data['member_id']} - " .
                "Member Name: {$member->member_name} - Loan Type: {$loanType->loan_type_name} - " .
                "Company: {$company->company_name}";

            // Check if a similar transaction already exists in `sacco_accounts_trans`
            $existingTrans = DB::table('sacco_accounts_trans')
                ->where('accounts_trans_sub_account', $data['sub_account'])
                ->where('accounts_trans_period', $data['period'])
                ->where('accounts_trans_doc_no', $data['doc_no'])
                ->where('accounts_trans_decription', $description)
                ->where('accounts_trans_dat_date', $data['date'])
                ->where('accounts_trans_user_id', $userId)
                ->first();

            DB::table('sacco_accounts_trans')->insert([
                'accounts_trans_sub_account' => $data['sub_account'],
                'accounts_trans_period' => $data['period'],
                'accounts_trans_debit' => $data['debit'],
                'accounts_trans_credit' => $data['credit'],
                'accounts_trans_doc_no' => $data['doc_no'],
                'accounts_trans_decription' => $description,
                'accounts_trans_dat_date' => $data['date'],
                'accounts_trans_user_id' => $userId,
                'accounts_trans_ip' => $userIp,
                'accounts_trans_transdate' => now()
            ]);

            // if ($existingTrans) {
            //     // Update existing transaction if it exists
            //     DB::table('sacco_accounts_trans')
            //         ->where('accounts_trans_id', $existingTrans->accounts_trans_id)
            //         ->update([
            //             'accounts_trans_debit' => $existingTrans->accounts_trans_debit + $data['debit'],
            //             'accounts_trans_credit' => $existingTrans->accounts_trans_credit + $data['credit'],
            //             //'updated_at' => now(),
            //         ]);
            // } else {
            //     // Insert a new transaction if it doesn't exist
            //     DB::table('sacco_accounts_trans')->insert([
            //         'accounts_trans_sub_account' => $data['sub_account'],
            //         'accounts_trans_period' => $data['period'],
            //         'accounts_trans_debit' => $data['debit'],
            //         'accounts_trans_credit' => $data['credit'],
            //         'accounts_trans_doc_no' => $data['doc_no'],
            //         'accounts_trans_decription' => $description,
            //         'accounts_trans_dat_date' => $data['date'],
            //         'accounts_trans_user_id' => $userId,
            //         'accounts_trans_ip' => $userIp,
            //         'accounts_trans_transdate' => now()
            //     ]);
            // }

            // Update the `sacco_sub_account` balance for debit and credit separately
            DB::table('sacco_sub_account')
                ->where('sub_account_id', $data['sub_account'])
                ->increment('sub_account_debit', $data['debit']);

            DB::table('sacco_sub_account')
                ->where('sub_account_id', $data['sub_account'])
                ->increment('sub_account_credit', $data['credit']);

            // Fetch the `main_account_id` linked to the `sub_account_id`
            $mainAccount = DB::table('sacco_sub_account')
                ->join('sacco_main_account', 'sacco_sub_account.sub_account_main_account', '=', 'sacco_main_account.main_account_id')
                ->where('sacco_sub_account.sub_account_id', $data['sub_account'])
                ->select('sacco_main_account.main_account_id')
                ->first();

            if (!$mainAccount) {
                dd("Error: Main account not found for sub-account ID {$data['sub_account']}");
            }

            // Update the main account with the debit and credit values separately
            DB::table('sacco_main_account')
                ->where('main_account_id', $mainAccount->main_account_id)
                ->increment('main_account_debit', $data['debit']);

            DB::table('sacco_main_account')
                ->where('main_account_id', $mainAccount->main_account_id)
                ->increment('main_account_credit', $data['credit']);
        } catch (\Exception $e) {
            dd("Error recording accounting transactions: " . $e->getMessage());
        }
    }

    /**
     * Recalculate interest and repayment for 'principle' (reducing balance) loans.
     */
    private function recalculateReducingBalanceLoan($loanId, $interestRate)
    {
        try {
            $loan = DB::table('sacco_loans')
                ->select('loan_amount', 'loan_loan_paid', 'loan_monthly_repayment_principal')
                ->where('loan_id', $loanId)
                ->first();

            if (!$loan) {
                Log::warning("Loan {$loanId} not found for recalculation.");
                return;
            }

            // ✅ Outstanding balance
            $balance = max(0, (($loan->loan_amount ?? 0)) - (($loan->loan_loan_paid ?? 0)));

            // ✅ Compute precise new interest (with decimals)
            $newInterest = $balance * $interestRate / 12 / 100;

            // ✅ Use stored principal *as-is*
            $principal = $loan->loan_monthly_repayment_principal ?? 0;

            // ✅ Extract the fractional (decimal) part of principal, e.g. 0.90 from 7168.90
            $principalWhole   = floor($principal);
            $principalDecimal = $principal - $principalWhole;

            // ✅ Add that decimal part to interest to keep totals consistent
            $newInterest += $principalDecimal;

            // ✅ Round/ceil interest to nearest full shilling
            $newInterest = ceil($newInterest);

            // ✅ Compute new total repayment — must tally exactly
            $newRepayment = $principalWhole + $newInterest;

            // ✅ Prevent overpayment
            if ($principalWhole > $balance) {
                $principalWhole = floor($balance);
                $newRepayment   = $principalWhole + $newInterest;
            }

            // ✅ Update only principal + repayment amount
            DB::table('sacco_loans')
                ->where('loan_id', $loanId)
                ->update([
                    'loan_monthly_repayment_principal' => $principalWhole,
                    'loan_monthly_repayment_amount'    => $newRepayment,
                ]);

            Log::info("Loan {$loanId} recalculated → Principal={$principalWhole}, Interest={$newInterest}, Total={$newRepayment}, Balance={$balance}");
        } catch (\Exception $e) {
            Log::error("Error recalculating reducing balance loan {$loanId}: " . $e->getMessage());
        }
    }
/**
 * Notify all active members with position = 2 that end-month loan processing has completed.
 */
public function notifyEndMonthCompletion($companyId, $loanTypeId, $period)
{
    try {
        // 1️⃣ Fetch company and loan type names
        $companyName = DB::table('sacco_company')
            ->where('company_id', $companyId)
            ->value('company_name');

        $loanTypeName = DB::table('sacco_loan_types')
            ->where('loan_type_id', $loanTypeId)
            ->value('loan_type_name');

        if (!$companyName || !$loanTypeName) {
            Log::warning("⚠️ Notification skipped: missing company or loan type name for IDs: {$companyId}, {$loanTypeId}");
            return;
        }

        // 2️⃣ Compose message details
        $subject = 'End-Month Loan Processing Complete';
        $message = "End-month loan processing for period {$period} has been successfully completed for {$companyName} ({$loanTypeName}).";

        // 3️⃣ Fetch recipients (position = 2, active)
        $recipients = DB::table('sacco_members')
            ->where('member_position', 2)
            ->where('member_active', 'Y')
            ->select('member_id', 'member_name', 'member_email', 'member_phone_no')
            ->get();

        if ($recipients->isEmpty()) {
            Log::warning("⚠️ No active position-2 members found to notify.");
            return;
        }

        // 4️⃣ Record notification for each recipient
        foreach ($recipients as $recipient) {
            DB::table('sacco_system_notifications')->insert([
                'notif_subject'          => $subject,
                'notif_message'          => $message,
                'notif_recipient_name'   => $recipient->member_name,
                'notif_recipient_email'  => $recipient->member_email,
                'notif_recipient_phone'  => $recipient->member_phone_no,
                'notif_member_id'        => $recipient->member_id,
                'notif_type'             => 'system',
                'notif_status'           => 'unread',
                'notif_created_at'       => now(),
                'notif_created_by'       => auth()->id() ?? 1,
                'notif_ip'               => request()->ip(),
            ]);

            Log::info("📩 Logged notification for {$recipient->member_name} ({$recipient->member_email}) — {$subject}");
        }

        Log::info("📣 Successfully recorded " . count($recipients) . " notifications for {$companyName} ({$loanTypeName}) — period {$period}.");
    } catch (\Exception $e) {
        Log::error("❌ Failed to record end-month notifications: " . $e->getMessage());
    }
}

}
