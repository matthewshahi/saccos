<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class PublicLoansController extends Controller
{
    public function loansTypesList()
    {
        $loanTypes = DB::table('sacco_loan_types')
            ->where('loan_type_deleted', 'N')
            ->orderBy('loan_type_name', 'asc')
            ->paginate(10);

        return view('public.loans_types_list', compact('loanTypes'));
    }

    public function calculator()
    {
        return view('public.loan_calculator');
    }

    public function loanDetails($id)
    {
        $loan = DB::table('sacco_loan_types')
            ->where('loan_type_id', $id)
            ->where('loan_type_deleted', 'N')
            ->first();

        if (!$loan) {
            return redirect()->route('loans.types.list')->with('error', 'Loan type not found.');
        }

        return view('public.loan_details', compact('loan'));
    }

    public function showLoanCalculator($id)
    {
        $loan = DB::table('sacco_loan_types')
            ->where('loan_type_id', $id)
            ->where('loan_type_deleted', 'N')
            ->first();

        if (!$loan) {
            return redirect()->route('loans.types.list')->with('error', 'Loan type not found.');
        }

        return view('public.loan_calculator', compact('loan'));
    }

    public function calculateLoan(Request $request, $id)
{
    $loan = DB::table('sacco_loan_types')
        ->where('loan_type_id', $id)
        ->where('loan_type_deleted', 'N')
        ->first();

    if (!$loan) {
        return redirect()->route('loans.types.list')->with('error', 'Loan type not found.');
    }

    // Validate inputs
    $validator = \Validator::make($request->all(), [
        'amount' => 'required|numeric|min:1|max:' . $loan->loan_type_max_amount,
        'duration' => 'required|integer|min:1|max:' . $loan->loan_type_duration,
    ]);

    if ($validator->fails()) {
        return redirect()->route('loan.calculator', ['id' => $id])
            ->withErrors($validator)
            ->withInput();
    }

    $loanAmount = $request->input('amount');
    $duration = $request->input('duration');
    $interestRate = (float) $loan->loan_type_interest;
    $interestType = strtolower(trim($loan->loan_type_interest_type));

    // 🔹 Fetch the loan_calc_method from sacco_defaults table
    $calcMethod = DB::table('sacco_defaults')
        ->where('default_name', 'loan_calc_method')
        ->value('default_value');

    // 🔹 Determine which method to use
    if ($interestType === 'reducing balance') {
        if ($calcMethod === 'principle') {
            // NEW: Principle-based reducing method
            $repaymentSchedule = $this->generatePrincipleReducingSchedule($loanAmount, $interestRate, $duration);
            $emi = null; // no equal EMI here
        } else {
            // Old standard EMI reducing balance
            $emi = $this->calculateReducingBalanceEMI($loanAmount, $interestRate, $duration);
            $repaymentSchedule = $this->generateReducingBalanceSchedule($loanAmount, $interestRate, $duration, $emi);
        }
    } else {
        // Fixed (Flat) interest
        $emi = $this->calculateFixedEMI($loanAmount, $interestRate, $duration);
        $repaymentSchedule = $this->generateFixedSchedule($loanAmount, $interestRate, $duration, $emi);
    }

    return view('public.loan_calculator', compact('loan', 'emi', 'repaymentSchedule'));
}


    // 🔹 Reducing balance: annual rate ÷ 12
    private function calculateReducingBalanceEMI($principal, $rate, $months)
    {
        if ($rate <= 0) {
            return $principal / $months;
        }

        $monthlyRate = $rate / 12 / 100;
        return $principal * $monthlyRate * pow(1 + $monthlyRate, $months)
               / (pow(1 + $monthlyRate, $months) - 1);
    }

     

    // 🔹 Generate Reducing Balance Schedule
    private function generateReducingBalanceSchedule($principal, $rate, $months, $emi)
    {
        $schedule = [];
        $monthlyRate = $rate / 12 / 100;

        for ($i = 1; $i <= $months; $i++) {
            $interest = $principal * $monthlyRate;
            $principalPayment = $emi - $interest;
            $principal -= $principalPayment;

            $schedule[] = [
                'month' => $i,
                'principal' => round($principalPayment, 2),
                'interest' => round($interest, 2),
                'emi' => round($emi, 2),
                'balance' => max(round($principal, 2), 0),
            ];
        }

        if (count($schedule)) {
            $schedule[count($schedule) - 1]['balance'] = 0;
        }

        return $schedule;
    }

     // ✅ Fixed (Flat) Interest — simple 6% ÷ months formula
private function calculateFixedEMI($principal, $rate, $months)
{
    // total interest for the full term
    $totalInterest = $principal * ($rate / 100);

    // monthly interest share
    $monthlyInterest = $totalInterest / $months;

    // monthly principal share
    $monthlyPrincipal = $principal / $months;

    // EMI per month = principal + interest portions
    return $monthlyPrincipal + $monthlyInterest;
}

private function generateFixedSchedule($principal, $rate, $months, $emi)
{
    $schedule = [];

    $totalInterest   = $principal * ($rate / 100);
    $monthlyInterest = $totalInterest / $months;
    $monthlyPrincipal = $principal / $months;

    for ($i = 1; $i <= $months; $i++) {
        $balance = $principal - ($monthlyPrincipal * $i);

        $schedule[] = [
            'month'     => $i,
            'principal' => round($monthlyPrincipal, 2),
            'interest'  => round($monthlyInterest, 2),
            'emi'       => round($emi, 2),
            'balance'   => max(round($balance, 2), 0),
        ];
    }

    return $schedule;
}

private function generatePrincipleReducingSchedule($principal, $rate, $months)
{
    $schedule = [];
    $monthlyPrincipal = $principal / $months; // equal principal portions
    $balance = $principal;
    $monthlyRate = $rate / 12 / 100;

    for ($i = 1; $i <= $months; $i++) {
        $interest = $balance * $monthlyRate;
        $payment = $monthlyPrincipal + $interest;
        $balance -= $monthlyPrincipal;

        $schedule[] = [
            'month' => $i,
            'principal' => round($monthlyPrincipal, 2),
            'interest' => round($interest, 2),
            'payment' => round($payment, 2),
            'balance' => max(round($balance, 2), 0),
        ];
    }

    return $schedule;
}

}